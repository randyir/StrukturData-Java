package doublelinkedlist;

public class APP{
    public static void main(String[] args) {
     DoubleLinkedList list = new DoubleLinkedList();
        list.insertFirst(5);
        list.insertFirst(3);
        list.insertFirst(2);
        list.insertLast(7);
        list.insertLast(11);
        list.insertLast(13);
        list.displayForward();
        list.displayBackward();
        list.deleteFirst();
        list.deleteLast();
        list.deleteKey(13);
        list.displayForward();
        list.insertAfter(11, 17);
        list.insertAfter(17, 19);
        list.displayForward();
    }
}